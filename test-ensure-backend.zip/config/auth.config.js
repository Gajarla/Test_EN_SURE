module.exports = {
    secret: "9z$B&E)H@McQfTjWnZr4u7x!A%D*F-Ja"
};